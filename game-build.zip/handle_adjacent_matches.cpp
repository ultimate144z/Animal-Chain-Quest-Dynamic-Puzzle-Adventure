#include <SFML/Graphics.hpp>
#include <time.h> 
#include <string.h>
#include <iostream>
#include "randomNum.h"
#include "handle_adjacent_matches.h"
#include "animateMovement.h"
#include "drawBoard.h"
#include "getIndices.h"
#include "fill_gaps.h"
#include <vector>
#include "drawScores.h"


using namespace std;

void incrementScore(const sf::Texture* texure, int matches);

int handle_adjacent_matches(){
    const sf::Texture* prev_texture;
    for (int row=0; row < boardHeight; ++row) {
        int matches = 0;
        prev_texture = gameBoard[row][0].getTexture();
        int col=1;
        for (; col < boardWidth; ++col) {
            if (
                gameBoard[row][col].getTexture() == prev_texture
            ){
                matches++;
                if(col==boardHeight-1 && matches >= 2)  // last itr
                {
                    matches++;
                    for (int prev_col = col; prev_col >col - matches; --prev_col){
                        gameBoard[row][prev_col].setPosition(prev_col*imageSize, -imageSize);
                        gameBoard[row][prev_col].setTexture(textures[randomNum(0, 6)]);
                    }
                    drawBoard(false, false, NULL);
                    drawScores();
                    window.display();
                    incrementScore(prev_texture, matches);
                    return matches;
                }
            }
            else {
                if (matches >= 2) {
                    matches++;
                    for (int prev_col = col - 1; prev_col >= col - matches; --prev_col){
                        gameBoard[row][prev_col].setPosition(prev_col*imageSize, -imageSize);
                        gameBoard[row][prev_col].setTexture(textures[randomNum(0, 6)]);
                    }

                    drawBoard(false, false, NULL);
                    drawScores();

                    window.display();
                    incrementScore(prev_texture, matches);
                    return matches;
                }
                matches = 0;

            }
            prev_texture = gameBoard[row][col].getTexture();
        
            
        }
        
    }


    for (int col=0; col < boardHeight; ++col) {
        int matches = 0;
        prev_texture = gameBoard[0][col].getTexture();
        int row = 1;
        for (; row < boardWidth; ++row) {
            if (
                gameBoard[row][col].getTexture() == prev_texture
            ){
                matches++;
                if (row==boardWidth-1 && matches >= 2) {
                    matches++;
                    for (int i=matches, prev_row = row; prev_row > row - matches; i--,  --prev_row){
 
                        gameBoard[prev_row][col].setPosition(col*imageSize, -i*imageSize);
                        gameBoard[prev_row][col].setTexture(textures[randomNum(0, 6)]);
                    
                    }
                    drawBoard(false, false, NULL);
                    drawScores();
                    window.display();
                    incrementScore(prev_texture, matches);

                    return matches;
                }
            }else {
                if (matches >= 2) {
                    matches++;
 
                    for (int i=matches, prev_row = row - 1; prev_row >= row - matches; --prev_row, i--)
                    {
                        gameBoard[prev_row][col].setPosition(col*imageSize, -i*imageSize); 
                        gameBoard[prev_row][col].setTexture(textures[randomNum(0, 6)]);
                        
                    }
                    drawBoard(false, false, NULL);
                    drawScores();
                    window.display();

                    incrementScore(prev_texture, matches);
                    return matches;
                }
                matches = 0;

            }
            
            
            
            prev_texture = gameBoard[row][col].getTexture();
        }


        
    }

    drawBoard(false, false, NULL, true);
    drawScores();
    window.display();

 
    return 0;
}

int findTextureIndex(const sf::Texture* texture){
    for(int i=0; i< imagesCount; ++i)
        if(texture==&textures[i])
            return i;
    return -1;
}

void incrementScore(const sf::Texture* texture, int matches){
    Repository& repo= repositories[findTextureIndex(texture)];
    repo.currentScore+=matches*pointsPerBox;
    if(repo.currentScore>repo.maxScore)
        repo.currentScore= repo.maxScore;
}
