#include <SFML/Graphics.hpp>
#include <iostream>
#include "getIndices.h"


using namespace std;


// convert x, y coordinates into corresponding board indices
int* getIndices(int x, int y) {
    int* indices = new int[2];
    indices[0] = y / imageSize;
    indices[1] = x / imageSize;
    if(indices[0]>=boardHeight || indices[1]>=boardWidth){
        indices[0]=-1;
        indices[1]=-1;
    }
    
    return indices;
}