#include <SFML/Graphics.hpp>
#include <time.h> 
#include <string>
#include <iostream>
#include "drawBoard.h"
#include "randomNum.h"
#include "animateMovement.h"
#include "getIndices.h"
#include "handle_mouse_release.h"
#include "fill_gaps.h"
#include "fixIndices.h"
#include "handle_adjacent_matches.h"
#include "drawMenu.h"
#include "drawScores.h"
#include "repoStruct.h"
#include <fstream>







#pragma comment(linker, "/SUBSYSTEM:windows /ENTRY:mainCRTStartup")
using namespace std;

// GRAPHICS VARs
const int boardWidth =8 ;
const int boardHeight = 8;
const int imagesCount = 7;
int imageSize = 100;            // 100x100 pixels
bool dragging = false;
int*  selected;                 // indices of selected box when dragging

const int screenWidth=1700;
const int screenHeight= 800;
sf::Clock timer;




const std::string working_dir="D:\\c++\\game\\";
// GAME LOGIC VARs

string GAME_MODE= "NORMAL";

int normalLevel = 0;
int timeTrialLevel= 0;
int movesCount   = 0;
int maxMoves     = 50;
const float maxTime= 5;                          // minutes;

int cascadeCount = 0; 
int cascadeBonus = imagesCount*20;             // 50 for each repo
int pointsPerBox = 50;
bool time_limit= false;
Repository repositories[7]={
    { 0, 0, 8000},
    { 0, 0, 7000},
    { 0, 0, 6000},
    { 0, 0, 5000},
    { 0, 0, 4000},
    { 0, 0, 3000},
    { 0, 0, 2000}
};


sf::Sprite gameBoard[boardHeight][boardWidth];
sf::Texture textures[imagesCount];
sf::RenderWindow window(sf::VideoMode(screenWidth, screenHeight), "Menagerie");


void handle_mouse_press(sf::Event event);
void initTextures();


void init_initial_scores(string mode);
bool checkLevel();
bool isLevelCompleted();
bool checkFail();

int main()
{
    srand(time(0));
    
    initTextures();

    drawMenu("MODE");
    drawMenu("LEVEL");
    while(!checkLevel()){
        drawMenu("LEVEL", "Please complete previous levels first.");
    }
    init_initial_scores(GAME_MODE);
    

    drawBoard(true, true, NULL);
    drawScores();
    window.display();
    
    int matches=handle_adjacent_matches();
    while(matches){
        fill_gaps();
        drawScores(true);
        matches=handle_adjacent_matches();
    }

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::MouseButtonPressed) {
                handle_mouse_press(event);
            }
            
            if(dragging && event.type == sf::Event::MouseMoved){
                sf::Sprite &selectedBox=gameBoard[selected[0]][selected[1]];
                
                selectedBox.setOrigin(imageSize/2, imageSize/2);
                selectedBox.setPosition(event.mouseMove.x, event.mouseMove.y);

                //selectedBox.move(5,5);
                //window.draw(selectedBox);
                drawBoard(false, false, selected);
                drawScores();
                window.display();
            }

            if (dragging && event.type == sf::Event::MouseButtonReleased) {
                handle_mouse_release(event);
            }
            

            

        }
        if(isLevelCompleted()){
            ifstream levelInfoIn(working_dir+"levelInfo.txt");
            int normalLevelCompleted=0;
            string temp;
            if(getline(levelInfoIn, temp))
                normalLevelCompleted= stoi(temp);

            int timeTrialLevelCompleted=0;
            if(getline(levelInfoIn,temp))
                timeTrialLevelCompleted= stoi(temp);
            
            levelInfoIn.close();

            ofstream levelInfo(working_dir+"levelInfo.txt");
            if(GAME_MODE=="NORMAL"){
                levelInfo << normalLevel << endl;
                levelInfo << timeTrialLevelCompleted << endl;
            }else if(GAME_MODE=="TIME TRIAL"){
                levelInfo << normalLevelCompleted << endl;
                levelInfo << timeTrialLevel << endl;
                
            }
            levelInfo.close();
            
            drawMenu("LEVEL", "Congrats, you have completed the level successfully. Now you can move to next Level");
            init_initial_scores(GAME_MODE);
            cout << "level ended scucessfully " << endl;
        }else if(checkFail()){
            drawMenu("LEVEL", "Sorry, you could not complete this level this time. Better luck next time");
        }else{
            drawBoard(false, false);
            drawScores();
            window.display();           
        }
    }

    return 0;
}


void initTextures(){
    for (int i = 0; i < imagesCount; ++i){
        string imgLoc = working_dir+"images/animal" +to_string(i+1) +".png";
        textures[i].loadFromFile(imgLoc);
        textures[i].setSmooth(true);
    }   
}

 
void handle_mouse_press(sf::Event event) {
    int* indices=getIndices(event.mouseButton.x, event.mouseButton.y);
    if(indices[0]!=-1)  // clicked inside board
    {
        dragging = true;
        selected=indices;
    }
}




void init_initial_scores(string mode){
    int incPerLevel= 2000;
    if(mode=="NORMAL"){
        pointsPerBox=50;

        for(int i=imagesCount+1, index=0; index<7; --i, index++){
            Repository& repo=repositories[index]; 
            repo.prevScore = 0;
            repo.currentScore  =  0;
            repo.maxScore = i *1000+(normalLevel-1)*incPerLevel;
        }
    }else{
        pointsPerBox=100;
        for(int i=imagesCount+1, index=0; index<7; --i, index++){
            Repository& repo=repositories[index];
            repo.prevScore = 0;
            repo.maxScore = i *1000+(timeTrialLevel-1)*incPerLevel;
            repo.currentScore  = repo.maxScore/2 ;
        };
    }
       
}



bool isLevelCompleted(){
    bool levelCompleted=true;

    for(int i=0; i < imagesCount; ++i)
        levelCompleted= levelCompleted &&
                        repositories[i].currentScore>=repositories[i].maxScore;

    return levelCompleted;
}


bool checkFail(){
    if(GAME_MODE=="NORMAL" && normalLevel==1)
        return movesCount>=maxMoves;
    else
        return movesCount>=maxMoves || timer.getElapsedTime().asSeconds()>=maxTime*60;
}
