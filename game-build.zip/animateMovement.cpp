#include <SFML/Graphics.hpp>
#include <time.h> 
#include <string.h>
#include <iostream>
#include "randomNum.h"
#include "drawBoard.h"
#include "animateMovement.h"
#include "getIndices.h"
#include "drawScores.h"



using namespace std;




// animate board boxes up, down, left, right movements 
// from current position by a specific count




void animateMovement(
    sf::Sprite* boxes[], 
    int direction,
    int* onTopIndices,
    int boxes_len,
    int move_count
) {    
    sf::Sprite *box= boxes[0];
    sf::Vector2f boxPos = box->getPosition();
    sf::Vector2f end= boxPos;

   
    float animationTime = 2;         
    float animationInc = 5;          // 5px movement increment

     if (direction == 0)                   //up
        end.y -= move_count*imageSize;
    else if (direction == 1)               //down
        end.y += move_count*imageSize;
    else if (direction == 2)               //left
        end.x -= move_count*imageSize;
    else if (direction == 3)               //right
        end.x += move_count*imageSize;

    while (
        !(boxPos.x == end.x &&
          boxPos.y == end.y)
    ) {
        for(int i=boxes_len-1; i>=0; --i){
            box=boxes[i];
            boxPos= box->getPosition();
            float x = boxPos.x, y = boxPos.y;
            int lastItr= boxes[0]->getPosition().x == end.x && 
                         boxes[0]->getPosition().y == end.y;

            if(!lastItr)
                if (direction == 0)                    //up
                    y -= animationInc;
                else if (direction == 1)               //down
                    y += animationInc;
                else if (direction == 2)               //left
                    x -= animationInc;
                else if (direction == 3)               //right
                    x += animationInc;
            
            box->setPosition(x, y);
  
        }
        
        if (!onTopIndices && getIndices(boxPos.x, boxPos.y)[0]!=-1)
            onTopIndices = getIndices(boxPos.x, boxPos.y);

        
        drawBoard(false, false, onTopIndices);
        drawScores();
        window.display();
        sf::sleep(sf::seconds(animationTime / float(imageSize) / animationInc));
    }

}