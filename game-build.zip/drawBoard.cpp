#include <SFML/Graphics.hpp>
#include <time.h> 
#include <string.h>
#include <iostream>
#include "randomNum.h"
#include "drawBoard.h"
#include "drawScores.h"


using namespace std;
sf::Sprite bg;
sf::Texture bg_image;


void drawBoard(
    bool setInitialPos,
    bool randomImg,
    int* onTop,
    bool display
) {

    bg_image.loadFromFile(working_dir+"images/menu_bg.jpg");

    bg.setTexture(bg_image);
    bg.setScale(1, 1.2);

    window.draw(bg);

    for (int row = 0; row < boardHeight; ++row)
        for (int col = 0; col < boardWidth; ++col) {

            float x = col * imageSize;
            float y = row * imageSize;

            if (randomImg)
                gameBoard[row][col]
                .setTexture(textures[randomNum(0, imagesCount - 1)]);

            if (setInitialPos)
                gameBoard[row][col].setPosition(sf::Vector2f(x, y));

            window.draw(gameBoard[row][col]);
        }

    if (onTop)
        window.draw(gameBoard[onTop[0]][onTop[1]]);

};