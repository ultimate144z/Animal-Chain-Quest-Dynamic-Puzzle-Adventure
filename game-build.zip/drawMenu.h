#pragma once


extern std::string GAME_MODE;
extern sf::RenderWindow window;
extern const int screenWidth;
extern const int screenHeight;

extern sf::Clock timer;
extern int normalLevel;
extern int timeTrialLevel;
extern int movesCount;
extern const std::string working_dir;


void drawMenu(std::string modeType="MODE", std::string message="");