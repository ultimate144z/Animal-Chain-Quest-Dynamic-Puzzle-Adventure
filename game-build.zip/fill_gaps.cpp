#include <SFML/Graphics.hpp>
#include <time.h> 
#include <string.h>
#include <iostream>
#include "randomNum.h"
#include "fill_gaps.h"
#include "animateMovement.h"
#include "fixIndices.h"
#include "handle_adjacent_matches.h"
#include "drawBoard.h"
#include "getIndices.h"
#include <cstdlib>
#include "drawScores.h"
using namespace std;

int search(int value, int arr[], int arr_len){
    for(int i=0; i<arr_len; ++i){
        if(arr[i]==value)
            return i;
    }
    return -1;
}


int fill_gaps(){

    int cols[8];
    int cols_len=0;
    sf::Sprite* to_shift[8*8];
    int to_shift_len=0;
    sf::Vector2f zero(0,0);
    
    for(int row=0; row<8; ++row){
        for(int col=0; col<8; ++col){
            sf::Vector2f pos=gameBoard[row][col].getPosition();        
            if(
                //gameBoard[row][col].getScale()==zero
                getIndices(pos.x, pos.y)[0]==-1
                && search(col, cols, cols_len)==-1
            ){
                cols[cols_len++]=col;
                for(int i=row-1; i>=0; --i)
                    to_shift[to_shift_len++]=&gameBoard[i][col];
                
            }
        }
    }


    int smallest_pos=-100;
    for(int row=0; row<8; ++row){
        for(int col=0; col<8; ++col){
            sf::Vector2f pos=gameBoard[row][col].getPosition(); 
            if(pos.y<smallest_pos)
                smallest_pos=pos.y;
            if(pos.y<0)
                to_shift[to_shift_len++]=&gameBoard[row][col];
        }
    }
    

    int move_count=abs(smallest_pos)/imageSize;
    
    
    if(to_shift_len)
        animateMovement(
            to_shift,
            1,
            NULL,
            to_shift_len,
            move_count
        );
    else {
        drawBoard(true, false, NULL, true);
        drawScores();
        window.display();
    }


    fixIndices();

    return to_shift_len;

}
