#include <SFML/Graphics.hpp>

#include "drawScores.h"
#include <string>
#include "drawBoard.h"
#include <iostream>

using namespace std;

sf::Sprite animals[7];
sf::Texture animal_textures[7];
sf::RectangleShape progressBarsBg[7], progressBarsFg[7];
sf::Text scores[7];


sf::Font font;
void drawInfo(){
    sf::Text heading;
    font.loadFromFile(working_dir+"font/EvilEmpire.ttf");

    int startX= 1230;

    int width= screenWidth-startX;

    heading.setFont(font);
    heading.setCharacterSize(60);
    heading.setFillColor(sf::Color::White);
    heading.setString("Menagerie Game");
    heading.scale(1, 1.4);
    sf::FloatRect textRect = heading.getLocalBounds();
    heading.setOrigin(textRect.left + textRect.width/2.0f,
            textRect.top  + textRect.height/2.0f);

    heading.setPosition(startX+width/2, 80);


    sf::RectangleShape timeBarBg;
    sf::RectangleShape timeBarFg;
    sf::Text timeLabel;
    sf::Text timeElapsed;

    int timeBarSize=300;
    int elapsedSec=timer.getElapsedTime().asSeconds();
    if(elapsedSec>maxTime*60)
        elapsedSec=maxTime*60;

    timeBarBg.setSize(sf::Vector2f(timeBarSize, 20));
    timeBarBg.setOrigin(timeBarSize/2, 0);
    timeBarBg.setFillColor(sf::Color(48, 108, 108));
    timeBarBg.setPosition(startX+width/2, 300);

    float timeBarFgSize= (elapsedSec/(maxTime*60))*timeBarSize;

    timeBarFg.setSize(sf::Vector2f(timeBarFgSize, 20));
    timeBarFg.setOrigin(0, 0);
    timeBarFg.setFillColor(sf::Color::Cyan);
    timeBarFg.setPosition(
        timeBarBg.getPosition().x-timeBarSize/2,
        timeBarBg.getPosition().y
    );

    timeLabel.setCharacterSize(25);
    timeLabel.setFont(font);
    timeLabel.setString("Time Elapsed");
    timeLabel.setPosition(
        timeBarFg.getPosition().x, 
        timeBarFg.getPosition().y-30
    );


    
    

    string timeStr="";
    timeStr+= to_string(int(elapsedSec/60));
    timeStr+= ":";
    timeStr+= to_string(int(elapsedSec%60));
    timeStr+= "/";
    timeStr+= to_string(int(maxTime));
    timeStr+= ":";
    timeStr+= to_string(int((maxTime-int(maxTime))*60));
    
    timeElapsed.setCharacterSize(25);
    timeElapsed.setFont(font);
    timeElapsed.setString(timeStr);
    sf::FloatRect timeElapsedRect = timeElapsed.getLocalBounds();
    timeElapsed.setOrigin(timeElapsedRect.width, 0);
    timeElapsed.setPosition(
        timeBarBg.getPosition().x+timeBarSize/2, 
        timeBarBg.getPosition().y-30
    );



    sf::RectangleShape movesBarBg;
    sf::RectangleShape movesBarFg;
    sf::Text movesLabel;
    sf::Text movesCountStatus;

    movesBarBg.setSize(sf::Vector2f(timeBarSize, 20));
    movesBarBg.setOrigin(timeBarSize/2, 0);
    movesBarBg.setFillColor(sf::Color(48, 108, 108));
    movesBarBg.setPosition(startX+width/2, 400);

    float movesBarFgSize= (float(movesCount)/maxMoves)*timeBarSize;

    movesBarFg.setSize(sf::Vector2f(movesBarFgSize, 20));
    movesBarFg.setOrigin(0, 0);
    movesBarFg.setFillColor(sf::Color::Cyan);
    movesBarFg.setPosition(
        movesBarBg.getPosition().x-timeBarSize/2,
        movesBarBg.getPosition().y
    );

    movesCountStatus.setCharacterSize(25);
    movesCountStatus.setFont(font);
    movesCountStatus.setString(to_string(movesCount)+"/"+ to_string(maxMoves));
    sf::FloatRect movesCountRect = movesCountStatus.getLocalBounds();
    movesCountStatus.setOrigin(movesCountRect.width, 0);
    movesCountStatus.setPosition(
        movesBarBg.getPosition().x+timeBarSize/2, 
        movesBarBg.getPosition().y-30
    );

    movesLabel.setCharacterSize(25);
    movesLabel.setFont(font);
    movesLabel.setString("Moves Left");
    movesLabel.setPosition(
        movesBarFg.getPosition().x, 
        movesBarFg.getPosition().y-30
    );

    sf::Text cascadeInfo;
    cascadeInfo.setCharacterSize(30);
    cascadeInfo.setFont(font);
    cascadeInfo.setString("Last Cascade Count: " + 
                            (cascadeCount==-1 ? "0" : to_string(cascadeCount))
                         );
    cascadeInfo.setPosition(
        movesBarFg.getPosition().x, 
        movesBarFg.getPosition().y+60
    );

    sf::Text cascadeBonusInfo;
    cascadeBonusInfo.setCharacterSize(30);
    cascadeBonusInfo.setFont(font);
    cascadeBonusInfo.setString("Last Cascade Bonus: " + 
                                (cascadeCount==-1 ? "0" : 
                                to_string(cascadeCount*cascadeBonus))
                              );
    cascadeBonusInfo.setPosition(
        cascadeInfo.getPosition().x, 
        cascadeInfo.getPosition().y+60
    );
    

    window.draw(heading);
    
    window.draw(movesLabel);
    window.draw(movesCountStatus);
    window.draw(movesBarBg);
    window.draw(movesBarFg);

    window.draw(cascadeInfo);
    window.draw(cascadeBonusInfo);
    
    // do not draw timer if first level of normal mode
    if(GAME_MODE=="NORMAL" && normalLevel==1)
        return; 
    window.draw(timeLabel);
    window.draw(timeElapsed);
    window.draw(timeBarBg);
    window.draw(timeBarFg);
    
}

void drawScores(int updateScoresUI){

    drawInfo();

    font.loadFromFile(working_dir+"font/EvilEmpire.ttf");
    for(int i=0; i<imagesCount; ++i){
        sf::Texture& animal_texture=animal_textures[i];
        
        animal_texture.loadFromFile(working_dir+"images/animal"+std::to_string(i+1)+"-rounded.png");
        animals[i].setTexture(animal_texture);
        animals[i].setOrigin(0, 100);
        // 4 for transparent border align;
        animals[i].setPosition(830, (i+1)*110+4);
        
        
        window.draw(animals[i]);

        sf::RectangleShape& progressBarBg=progressBarsBg[i];
        sf::RectangleShape& progressBarFg= progressBarsFg[i];
        sf::Text& score=scores[i];

        int progressBarSize= 300;
        Repository &repo=repositories[i];
        

        score.setFillColor(sf::Color::White);
        score.setCharacterSize(25);
        score.setFont(font);
        string scoreStr=to_string(repo.prevScore)+"/"+to_string(repo.maxScore);
        score.setString(scoreStr);
        sf::FloatRect scoreRect = score.getLocalBounds();

        score.setOrigin(scoreRect.width, 0);

        score.setPosition(930+progressBarSize, (i+1)*110 -50);


        progressBarBg.setSize(sf::Vector2f(progressBarSize, 20));
        progressBarBg.setPosition(930, (i+1)*110-20);
        progressBarBg.setFillColor(sf::Color(48, 108, 108));
        
        
        progressBarFg.setPosition(930, (i+1)*110-20);
        progressBarFg.setFillColor(sf::Color::Cyan);
        
        
       
        float scorePercentage= 
            float(repo.prevScore)/repo.maxScore;
        if(scorePercentage>1)
            scorePercentage=1;
        progressBarFg.setSize(
            sf::Vector2f(
                progressBarSize*scorePercentage, 20
            )
        );
        window.draw(progressBarBg);
        window.draw(progressBarFg);
        window.draw(score);
        
    }
    for(int i=0; i<imagesCount; ++i){
        Repository &repo=repositories[i];

        if(updateScoresUI && repo.prevScore<repo.currentScore){
            window.display();


            drawBoard(true, false);
            float newScore=repo.prevScore+50;
            if(newScore> repo.currentScore)
                newScore =repo.currentScore;
            
            repo.prevScore= newScore;
            drawScores(newScore);
        }
    }
}