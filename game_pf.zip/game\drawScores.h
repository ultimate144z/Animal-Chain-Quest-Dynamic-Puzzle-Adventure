#pragma once
#include "repoStruct.h"
extern const int imagesCount;


extern Repository repositories[7];

extern sf::RenderWindow window;
extern const std::string working_dir;
extern sf::Clock timer;
extern const int screenWidth;
extern const float maxTime;

extern int movesCount;
extern int maxMoves;

extern int cascadeCount;
extern int cascadeBonus;

extern std::string GAME_MODE;
extern int normalLevel;

void drawScores(int updateScoresUI=0);