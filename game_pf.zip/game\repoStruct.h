#pragma once


struct Repository{
    int prevScore;
    int currentScore;
    int maxScore;
};
