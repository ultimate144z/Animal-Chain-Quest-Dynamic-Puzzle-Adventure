#pragma once


int randomNum(int min, int max);
