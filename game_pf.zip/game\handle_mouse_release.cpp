
#include <SFML/Graphics.hpp>
#include <time.h> 
#include <string.h>
#include <iostream>
#include "randomNum.h"
#include "handle_adjacent_matches.h"
#include "animateMovement.h"
#include "drawBoard.h"
#include "getIndices.h"
#include "handle_mouse_release.h"
#include "fill_gaps.h"
#include "fixIndices.h"
#include "drawScores.h"


using namespace std;



int handle_mouse_release(sf::Event event) {
    dragging = false;
    sf::Sprite& selectedBox = gameBoard[selected[0]][selected[1]];
    selectedBox.setOrigin(0, 0);

    int* targetIndices = getIndices(event.mouseButton.x, event.mouseButton.y);
    int validTargets[4][2] = {
        {selected[0] - 1, selected[1]},     // up
        {selected[0] + 1, selected[1]},     // down
        {selected[0], selected[1] - 1},     // left
        {selected[0], selected[1] + 1}      // right
    };

    bool isValidMove = false;
    int i;
    for (i = 0; i < 4; ++i) {
        if (
            validTargets[i][0] == targetIndices[0] &&
            validTargets[i][1] == targetIndices[1]
            ) {
            isValidMove = true;
            break;
        }
    }
    if (!isValidMove) {
        // move back to initial pos and dont randomize images
        drawBoard(true, false);
        drawScores();
        window.display();
        return 1;
    }

    // if move is valid
    //cout << "target indices are " << targetIndices[0] << ", " << targetIndices[1] << endl;

    sf::Sprite& targetBox = gameBoard[targetIndices[0]][targetIndices[1]];
    sf::Vector2f targetPos = targetBox.getPosition();
    float animationTime = .7;      // second
    float animationInc = 5;    // 5px increment    

    float selectedOrigX = selected[1] * imageSize;
    float selectedOrigY = selected[0] * imageSize;
    selectedBox.setOrigin(0, 0);
    selectedBox.setPosition(
        targetIndices[1] * imageSize,
        targetIndices[0] * imageSize
    );
    window.draw(selectedBox);
    window.display();



    int animate_direction = -1;
    if (i == 0)                    //up
        animate_direction = 1;
    else if (i == 1)               //down
        animate_direction = 0;
    else if (i == 2)               //left
        animate_direction = 3;
    else if (i == 3)               //right
        animate_direction = 2;

    /*animateMovement(
        targetBox,
        sf::Vector2f(selectedOrigX, selectedOrigY),
        animate_direction
    );*/

    sf::Sprite* boxes[1];
    boxes[0]=&targetBox;
    animateMovement(
        boxes,
        animate_direction
    );



    // swap in map aswell
    sf::Sprite temp = selectedBox;
    selectedBox = targetBox;
    targetBox = temp;
    // remove any boxes which are left on top while drag
    drawBoard(true, false);
    drawScores();
    window.display();

    cascadeCount=-1;

    int matches=handle_adjacent_matches();
    movesCount++;

    while(matches){        
        fill_gaps();
        drawBoard(true, false);
        drawScores(true);
        window.display();
        matches=handle_adjacent_matches();
        cascadeCount++;
    }

    if(cascadeCount==-1)
        cascadeCount=0;
    for(int i=0; i<imagesCount; i++)
        repositories[i].currentScore+=(cascadeBonus/imagesCount)*cascadeCount;

    drawBoard(true, false);
    drawScores(true);
    window.display();
    
}
