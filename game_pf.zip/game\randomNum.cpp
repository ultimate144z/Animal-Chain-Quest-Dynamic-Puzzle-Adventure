#include "randomNum.h"
#include <time.h>
#include <stdlib.h>

using namespace std;
int randomNum(int min, int max) {
    int range = max - min + 1;
    int num = rand() % range + min;
    return num;
};