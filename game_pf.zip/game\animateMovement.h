#pragma once

extern const int boardWidth;
extern const int boardHeight;
extern const int imagesCount;
extern int imageSize;            // 100x100 pixels
extern bool dragging;
extern int* selected;
extern int test_map[8][8];


extern sf::Sprite gameBoard[8][8];
extern sf::Texture textures[7];
extern sf::RenderWindow window;

void animateMovement(
    sf::Sprite* boxes[], 
    int direction,
    int* onTopIndices=NULL,
    int boxes_len=1,
    int move_count=1
);