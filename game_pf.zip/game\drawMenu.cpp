#include <SFML/Graphics.hpp>
#include "drawMenu.h"
#include <string>
#include <iostream>
#include <fstream>


using namespace std;

sf::Sprite menu;
sf::Texture menu_image;
sf::Font menu_font;
sf:: Text reselect_mode;




bool MENU=true;

int menuType=0;                 // 0: mode menu     1: levels menu

void handle_menu_click(sf::Event event, string menuType);
void displayMenu(
    string menuType="MODE", 
    string message="",
    float mouseX=0, 
    float mouseY=0
);
bool mouseOver(sf::Text menu_text, float mouseX, float mouseY);
bool checkLevel();

string modeMenuStrings[2]={
    "Normal Mode",
    "Time Trial Mode"
};
sf::Text modeMenuTexts[2];
int modeMenuLen=2;
int modeMenuChSize=100;
int modeMenuItemHeight=200;
int modeMenuTopMargin=100;


string levelMenuStrings[2]={
    "Level One",
    "Level Two"
};
sf::Text levelMenuTexts[2];
int levelMenuLen=2;
int levelMenuChSize=70;
int levelMenuItemHeight=100;
int levelMenuTopMargin=200;



void drawMenu(string menuType, string message){
    MENU=true;
    displayMenu(menuType, message);
    while(MENU && window.isOpen()){
       
        sf::Event event;

        while (MENU && window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::MouseButtonPressed) {
                handle_menu_click(event, menuType);
            }
            if(event.type == sf::Event::MouseMoved){
                displayMenu(
                    menuType,
                    message,
                    event.mouseMove.x, 
                    event.mouseMove.y
                );
            }
        }

    }
}


void displayMenu(string menuType, string message, float mouseX, float mouseY){
    sf::Text* menu_texts = modeMenuTexts;
    string* menuStrings = modeMenuStrings;
    int menu_len = modeMenuLen;
    int menuChSize = modeMenuChSize;
    int menuItemHeight= modeMenuItemHeight;
    int menuTopMargin= modeMenuTopMargin;
    if(menuType=="LEVEL"){
        menu_texts= levelMenuTexts;
        menuStrings= levelMenuStrings;
        menu_len= levelMenuLen;
        menuChSize= levelMenuChSize;
        menuItemHeight= levelMenuItemHeight;
        menuTopMargin= levelMenuTopMargin;
    }

    menu_font.loadFromFile(working_dir+"font/EvilEmpire.ttf");
    menu_image.loadFromFile(working_dir+"images/menu_bg.jpg");

    menu.setTexture(menu_image);
    menu.setScale(1, 1.2);

    window.draw(menu);
    sf::Text messageText;
    messageText.setFont(menu_font);
    messageText.setCharacterSize(40);
    messageText.setString(message);
    sf::FloatRect msgRect = messageText.getLocalBounds();
    messageText.setOrigin(
            msgRect.left + msgRect.width/2.0f,
            msgRect.top  + msgRect.height/2.0f
    );

    messageText.setPosition(screenWidth/2, 100);
    messageText.setFillColor(sf::Color::Magenta);
    window.draw(messageText);
    int i=0;
    for(; i< menu_len; i++){
        sf:: Text& menu_text=menu_texts[i];
        menu_text.setFont(menu_font);
        menu_text.setCharacterSize(menuChSize);
        
        menu_text.setString(menuStrings[i]);
        sf::FloatRect textRect = menu_text.getLocalBounds();
        menu_text.setOrigin(textRect.left + textRect.width/2.0f,
                textRect.top  + textRect.height/2.0f);

        menu_text.setPosition(screenWidth/2, (i+1)*menuItemHeight+menuTopMargin);

        bool mouse_over= mouseOver(menu_text, mouseX, mouseY);
        menu_text.setFillColor(
            mouse_over ? sf::Color::Magenta : sf::Color::Cyan
        );
        window.draw(menu_text);   
    }
    // if mode menu then do not draw reselect mode option
    if(menuType=="MODE"){
        window.display();
        return;
    }

    // reselect mode option
    reselect_mode.setFont(menu_font);
    reselect_mode.setCharacterSize(menuChSize);
    
    reselect_mode.setString("Reselect Mode");
    sf::FloatRect textRect = reselect_mode.getLocalBounds();
    reselect_mode.setOrigin(textRect.left + textRect.width/2.0f,
            textRect.top  + textRect.height/2.0f);

    reselect_mode.setPosition(screenWidth/2, (i+1)*menuItemHeight+menuTopMargin);

    bool mouse_over= mouseOver(reselect_mode, mouseX, mouseY);
    reselect_mode.setFillColor(
        mouse_over ? sf::Color::Magenta : sf::Color::Cyan
    );
    window.draw(reselect_mode);
    window.display();
}


bool mouseOver(sf::Text menu_text, float mouseX, float mouseY){
    sf::FloatRect textRect = menu_text.getLocalBounds();
    sf::Vector2f pos=menu_text.getPosition();
    pos.x= pos.x-textRect.width/2;
    pos.y= pos.y-textRect.height/2;

        
    return  mouseX>=pos.x && mouseX<= pos.x+textRect.width &&
            mouseY>=pos.y && mouseY<= pos.y+textRect.height;

}

void handle_menu_click(sf::Event event, string menuType){
    if(
        mouseOver(
            reselect_mode, 
            event.mouseButton.x, 
            event.mouseButton.y
        ) && menuType=="LEVEL"
    ){
        drawMenu("MODE");
        drawMenu("LEVEL");
        return;
    }
    
    if(menuType=="MODE"){
        if(mouseOver(modeMenuTexts[0], event.mouseButton.x, event.mouseButton.y)){
            GAME_MODE="NORMAL";
        }
        else{
            GAME_MODE="TIME TRIAL";
        }
    }else if(menuType=="LEVEL"){
        if(GAME_MODE=="NORMAL"){
            if(mouseOver(levelMenuTexts[0], event.mouseButton.x, event.mouseButton.y))
                normalLevel=1;
            else
                normalLevel=2;

        }else if(GAME_MODE=="TIME TRIAL"){
            if(mouseOver(levelMenuTexts[0], event.mouseButton.x, event.mouseButton.y))
                timeTrialLevel=1;
            else
                timeTrialLevel=2;
        }
        timer.restart();  
        movesCount=0; 
        while(!checkLevel()){
            drawMenu("LEVEL", "Please complete previous levels first.");
        }
    }
    MENU=false;

}


bool checkLevel(){
    ifstream levelInfo(working_dir+"levelInfo.txt");
    int normalLevelCompleted=0;
    string temp;
    if(getline(levelInfo, temp))
        normalLevelCompleted= stoi(temp);

    int timeTrialLevelCompleted=0;
    if(getline(levelInfo,temp))
        timeTrialLevelCompleted= stoi(temp);
   

    cout << "normal levels completed " << normalLevelCompleted << endl;
    cout << "time trial levels completed " << timeTrialLevelCompleted << endl;
    cout << "normal level is " << normalLevel << endl;
    cout << "timeTrialLevel is " << timeTrialLevel << endl;
    cout << "GAME_MODE IS " << GAME_MODE << endl;
    if(GAME_MODE=="NORMAL")
        return normalLevel-1 <= normalLevelCompleted;
    else if(GAME_MODE=="TIME TRIAL")
        return timeTrialLevel-1 <= timeTrialLevelCompleted;
}


