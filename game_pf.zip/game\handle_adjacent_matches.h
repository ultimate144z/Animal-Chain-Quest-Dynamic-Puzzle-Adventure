#pragma once
#include "drawBoard.h"
#include "repoStruct.h"

extern const int boardWidth;
extern const int boardHeight;
extern const int imagesCount;
extern int imageSize;            // 100x100 pixels
extern bool dragging;
extern int*  selected;
extern int test_map[8][8];
extern bool animating;

extern sf::Sprite gameBoard[8][8];
extern sf::Texture textures[7];
extern sf::RenderWindow window;
extern Repository repositories[7];
extern int pointsPerBox;


//void handle_adjacent_matches(sf::Vector2f selectedPos, int direction);
int handle_adjacent_matches();
