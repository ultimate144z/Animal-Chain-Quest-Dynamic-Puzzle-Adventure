#include <SFML/Graphics.hpp>
#include <time.h> 
#include <string.h>
#include <iostream>
#include "randomNum.h"
#include "fill_gaps.h"
#include "animateMovement.h"
#include "fixIndices.h"
#include "drawBoard.h"

using namespace std;




sf::Sprite* findByXY(sf::Sprite gameBoardCopy[8][8], float x, float y){
    sf::Sprite* result=NULL;          // there would be max two on same pos
    
    for(int row=0; row<boardHeight; ++row){
        for(int col=0; col<boardWidth; ++col){
            sf::Vector2f pos= gameBoardCopy[row][col].getPosition();
            if (pos.x ==x && pos.y== y)
                result = &gameBoardCopy[row][col];
        }
    }
    return result;
}


bool fixIndices(){
    bool gaps_found=false;
    sf::Sprite gameBoardCopy[8][8];

    for(int row=0; row<boardHeight; ++row){
        for(int col=0; col<boardWidth; ++col){
            gameBoardCopy[row][col]=gameBoard[row][col];
        }
    }

    for(int row=0; row<boardHeight; ++row){
        for(int col=0; col<boardWidth; ++col){
            sf::Sprite* box=findByXY(gameBoardCopy, col*imageSize, row*imageSize);
          
            if(box!=NULL)
                gameBoard[row][col]=*box;
           
        }
        
    }
    
    return gaps_found;

}